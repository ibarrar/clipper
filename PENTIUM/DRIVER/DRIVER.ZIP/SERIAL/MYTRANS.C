

    config.port = portno;
    config.baud_rate = baudrate;
    config.parity = parity;
    config.lock_port = FALSE;
    sprintf(config.initialization_string, "ATS0=0V1X4^M");
    sprintf(config.hangup_string, "~~~+++~~~ATH0^M");
    sprintf(config.dial_prefix, "ATDT");

    if (!open_port(config.port, 4096))       /* open the comm port */
    {
       _retni(PORT_FAILED);
       return;
    }

    /* configure the port if no carrier */
    /* printf("\ndetecting carrier\n"); */
    if (!carrier())
       {
            set_port(config.baud_rate, config.parity ? 8 : 7,
            config.parity ? NO_PARITY : EVEN_PARITY, 1);
       }
    set_tx_rts(TRUE);                                       /* set XON/XOFF and RTS/CTS */
    set_tx_xon(TRUE);                                       /* flow control */
    set_rx_rts(TRUE);
    set_rx_xon(TRUE);

    while (in_ready()) {
    get_serial();
    }

    close_port();    