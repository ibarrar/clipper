
#ifdef __TURBOC__
 #include <dos.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "serial.h"
#include "extend.h"

/* data format constants
#define P8N1 1
#define P7E1 0
*/

/* configuration file record structure */
typedef struct {
    int port;
    long baud_rate;
    int parity;
    int lock_port;
    char initialization_string[81];
    char hangup_string[41];
    char dial_prefix[41];
} CONFIG;

/* ERRORs */

#define NORMAL          0
#define PORT_FAILED     1
#define DIAL_FAILED     2
#define UPLOAD_FAILED   3
#define LOW_MEM         4
#define INV_PARAM       5
#define FILE_NOT_FOUND  6
#define INIT_FAILED     7
#define DOWNLOAD_FAILED 8

/* function prototypes */

void config_program(void);
int dial(char *number, int retries);
char *get_modem_string(char *s, char *d);
void hangup(void);
void modem_control_string(char *s);
int upload(int protocol_type, char *line);
int download(char *cdir);
int e_handler(int c, long p, char *s);

#define PORTNO      1
#define BAUDRATE    2
#define PARITY      3
#define TELNO       4
#define FILENAME    5
#define FILECOUNT   6
#define DIAL_RETRY  7
#define TPROTOCOL   8
#define DOWN_RETRY  9
#define FILEPATH    10

/* #pragma intrinsic (memset, memcpy) */

char *files[10];
CONFIG config;

/* int transfer_file(int portno,long baudrate,int parity,char *telno,char *filename, int filecount, int dial_retry, int tprotocol, int down_retry, char *filepath) */
CLIPPER xfer_file()
{
    int retval,down_retry;
    int i,fpathlen,filecount,telnolen,portno,parity,dial_retry,tprotocol;
    long baudrate;
    char *telno1,telno[81],filename[81],*fpath,filepath[81];

    if (PCOUNT != FILEPATH || !ISNUM(PORTNO) || !ISNUM(BAUDRATE) || !ISNUM(PARITY)
            || !ISCHAR(TELNO) || !ISNUM(FILECOUNT)
            || !ISNUM(DIAL_RETRY) || !ISNUM(TPROTOCOL)
            || !ISNUM(DOWN_RETRY))
    {
       _retni(INV_PARAM);
       return;
    }

        portno = _parni(PORTNO);
      baudrate = _parnl(BAUDRATE);
        parity = _parni(PARITY);
        telno1 = _parc(TELNO);
      telnolen = _parclen(TELNO);
     filecount = _parni(FILECOUNT);
    down_retry = _parni(DOWN_RETRY);

    _bset(filepath,0x0,sizeof(filepath));
    fpathlen = _parclen(FILEPATH);
       fpath = _parc(FILEPATH);
    _bcopy(filepath,fpath,fpathlen);

    for(i=0; i < filecount; i++)
    {
       files[i] = _parc(FILENAME,i+1);
       files[i+1] = NULL;
    }

    _bset(telno,0x0,sizeof(telno));
    _bcopy(telno,telno1,telnolen);
    
    dial_retry = _parni(DIAL_RETRY);
     tprotocol = _parni(TPROTOCOL);
    
    config.port = portno;
    config.baud_rate = baudrate;
    config.parity = parity;
    config.lock_port = FALSE;
    sprintf(config.initialization_string, "ATS0=0V1X4^M");
    sprintf(config.hangup_string, "~~~+++~~~ATH0^M");
    sprintf(config.dial_prefix, "ATDT");
    
    
    if (!open_port(config.port, 4096))       /* open the comm port */
    {
       _retni(PORT_FAILED);
       return;
    }

    /* configure the port if no carrier */
    /* printf("\ndetecting carrier\n"); */
    if (!carrier())
    {
       set_port(config.baud_rate, config.parity ? 8 : 7,
       config.parity ? NO_PARITY : EVEN_PARITY, 1);
    }
    set_tx_rts(TRUE);                                       /* set XON/XOFF and RTS/CTS */
    set_tx_xon(TRUE);                                       /* flow control */
    set_rx_rts(TRUE);
    set_rx_xon(TRUE);
    /* reset the modem and send initialization string if no carrier */
    /* printf("\ninitializing modem\n"); */
    if (!carrier()) {
        modem_control_string("ATZ^M");
        delay(1500);
        modem_control_string(config.initialization_string);
        delay(500);
    }
    while (in_ready()) {
    get_serial();
    }
    /* printf("\nDialing...\n"); */
    retval = dial(telno,dial_retry);
    /* printf("\nFinished dialing = %d\n",retval); */
    if (retval)
    {
       delay(1000);
       /* printf("Sending file...%s\n",filename); */
       if (!upload(tprotocol,filename))
          retval = UPLOAD_FAILED;
       else
       {
          retval = NORMAL;
          for(i=0;i<down_retry;i++)
             {
             if (download(filepath))
                {
               /* retval = NORMAL; */
                break;
		}
             delay(300);
             }
          /* retval = DOWNLOAD_FAILED; */
       }
    }
    else
    {
       retval = DIAL_FAILED;
       /* printf("Unable to connect...\n"); */
    }
    hangup();
    close_port();
    _retni(retval);
}

/* download file routine */
int download(char *cdir)
{
    if (recv_file(YMODEM, e_handler, cdir) == TRUE) /* get the file */
    {
       return(TRUE);
    }
    else
    {
       return(FALSE);
    }
}


/* file transfer error handler */
int e_handler(int c, long p, char *s)
{
/*    int k; */

    switch (c) {
        case SENDING:                           /* file is being sent */
          /* printf("Sending: %s\n", strupr(s));
             printf("Length : %ld\n", p); */
          return TRUE;
        case RECEIVING:                         /* file is being received */
          /* printf("Receiving: %s\n", strupr(s));
             printf("Length : %ld\n", p); */
          return TRUE;
        case SENT:                              /* block was sent */
          /* printf("%ld bytes sent.\r", p); */
          return TRUE;
        case RECEIVED:                          /* block was received */
          /* printf("%ld bytes received.\r", p); */
          return TRUE;
        case ERROR:                             /* an error occurred */
          /* printf("\nError: %s in block %ld\n", s, p); */
          return FALSE;
        case COMPLETE:                          /* file transfer complete */
          /* printf("\n%s\n", s); */
          return TRUE;
    }
    return TRUE;
}


/* upload a file */
int upload(int protocol_type, char *line)
{
    int c;
    if (!*line)
       return FALSE;

    /* printf("From Upload: protocol = %d\n",protocol_type); */

    return xmit_file(protocol_type, e_handler, files);
}

/* dial routine */
int dial(char *number, int retries)
{
    int br,try=0;
    char line[81], dstring[81];

    if (!*number)
    return FALSE;
    sprintf(dstring, "%s%s", config.dial_prefix, number);
    while (TRUE) {
       try++;
       /* printf("\nretries = %d\n",retries);
       printf("try = %d\n",try); */
       if (try > retries)
          return FALSE;
       delay(2000);
       sprintf(line, "%s^M", dstring);
       /* printf("\nDialing number = %s\n",number); */
       modem_control_string(line);     /* dial the number */
       get_modem_string(line, dstring); /* get a response */
        /* connection was made */
       /* printf("\n%s\n", line); */
        /* dial interrupted by user */
       if (!strcmp(line, "INTERRUPTED")) {
           /* printf("\n"); */
           return FALSE;
        }
        /* user wants to repeat the dial immediately */
        if (!strcmp(line, "RECYCLE")) {
            /* printf("\n"); */
            continue;
        }
        if (strstr(line, "CONNECT") != NULL) {
            /* set DTE rate to match the connection rate if port */
            /*  isn't locked */
            if (!config.lock_port) {
                br = atoi(line + 7);
                if (br)
                    set_baud(br);
                else
                    set_baud(300);
            }

           return TRUE;
        }
    /* printf("\n%s\n", line); */        /* display the result string */
    }
}

/* get response string */
char *get_modem_string(char *s, char *d)
{
    int i, c;
    unsigned last;

    last = mpeek(0, 0x46c);
    i = 1092;
    *s = 0;
    /* printf("%-2d", (i * 10) / 182); */    /* display time remaining */
    while (TRUE) {
        /* get a character from the port if one's there */
        if (in_ready()) {
            switch (c = get_serial()) {
                case 13:                /* CR - return the result string */
                    if (*s)
                        return s;
                    continue;
                default:
                    if (c != 10) {      /* add char to end of string */
                        s[strlen(s) + 1] = 0;
                        s[strlen(s)] = (char)c;
                        /* ignore RINGING and the dial string */
                        if (!strcmp(s, "RINGING") || !strcmp(s, d))
                            *s = 0;
                    }
            }
        }
        if (carrier())
           {
           strcpy(s,"CONNECT");
           return s;
           }
        /* check for timeout and display time remaining */
        if (last != mpeek(0, 0x46c)) {
            last = mpeek(0, 0x46c);
            i--;
            /* printf("\b \b\b \b%-2d", (i * 10) / 182); */
            if (!i) {
                *s = 0;
                put_serial(13);
                return s;
            }
        }
    }
}


/* Hang Up Modem Routine */
void hangup(void)
{
    int i;
    unsigned last;

    last = mpeek(0, 0x46c);             /* get current system clock */
    i = 180;                            /* try for about 10 seconds */
    set_dtr(FALSE);                                         /* drop DTR */
    while (carrier() && i) {                        /* loop till loss of carrier */
        if (last != mpeek(0, 0x46c)) {  /*  or time out */
            i--;
            last = mpeek(0, 0x46c);
        }
    }
    set_dtr(TRUE);                                          /* raise DTR */
    if (!carrier()) {                                       /* return if disconnect */
        purge_in();
        return;
    }
    modem_control_string(config.hangup_string);             /* send software command */
    i = 180;                                                /* try for about 10 seconds */
    while (carrier() && i) {                                /* loop till loss of carrier */
        if (last != mpeek(0, 0x46c)) {                      /*  or time out */
            i--;
            last = mpeek(0, 0x46c);
        }
    }
    purge_in();
}

/* Send Control String to Modem */
void modem_control_string(char *s)
{
    while (*s) {                                            /* loop for the entire string */
        switch (*s) {
            case '~':                                       /* if ~, wait a half second */
                delay(500);
                break;
            default:
                switch (*s) {
                    case '^':                               /* if ^, it's a control code */
                        if (s[1]) {                         /* send the control code */
                            s++;
                            put_serial((unsigned char)(*s - 64));
                        }
                        break;
                    default:
                        put_serial(*s);                     /* send the character */
                }
                delay(50);                                  /* wait 50 ms. for slow modems */
        }
        s++;                                                /* bump the string pointer */
    }
}


  
