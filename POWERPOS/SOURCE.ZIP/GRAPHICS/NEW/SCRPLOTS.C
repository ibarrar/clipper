#include "gdraws.h"

void plots(int x, int y, int color)
{
	convert(x,y);
	plot(x,y,color);
}