#include <extend.h>
#include <conio.H>

CLIPPER OPEN_DRAWR()
{
  int retries = 10;

  do 
  {  
    retries--;
    
    outp(0x260,0x14);
    outp(0x261,0x04);

    outp(0x260,0x15);
    outp(0x261,0x01);

    outp(0x260,0x14);
    outp(0x261,0x04);

  }while ((inp(0x267) & 0x40) && retries > 0);  

  _ret();
}

CLIPPER CHK_DRAWR()
{
   
  outp(0x260,0x14);
  outp(0x261,0x04);

  _retni( (inp(0x267) & 0x40) ? 19 : 18);
}